<template>
<div>

</div>

</template>

<script>
  export default {
    name: 'member',
    data () {
      return {
        msg: 'member'
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  /*@import './member_base.css';*/
  /*@import './member.css'*/
</style>
