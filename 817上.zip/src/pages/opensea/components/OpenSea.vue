<template>

</template>

<script>
  export default {
    name: 'OpenSea',
    data () {
      return {
        msg: 'OpenSea'
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
